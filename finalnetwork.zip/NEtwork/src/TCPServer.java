import java.io.*; 
import java.net.*; 

public class TCPServer {

	  public static void main(String argv[]) throws Exception 
	    { 
	      String Sentence; 
	      String capitalizedSentence; 

	      ServerSocket welcomeSocket = new ServerSocket(1500); 
	  
	      while(true) { 
	    	  
	            Socket connectionSocket = welcomeSocket.accept(); 

	           BufferedReader inFromClient = 
	              new BufferedReader(new
	              InputStreamReader(connectionSocket.getInputStream())); 
	           Sentence = inFromClient.readLine();
		    
	           if(Sentence.equals("connect")) {
	        	   System.out.println(" Connected");
	        	   while(true) {
	    	           Sentence = inFromClient.readLine();
	    	           
	        		   if(!Sentence.equals("exit")) {
	        			   
	        		   
	        		   
	       		        System.out.println("Client: "+Sentence);
	        	   
	           
	           DataOutputStream  outToClient = 
	                   new DataOutputStream(connectionSocket.getOutputStream()); 

	                 
	     	        

	                 capitalizedSentence = Sentence.toUpperCase() + '\n'; 

	                 outToClient.writeBytes(capitalizedSentence); 
	              }
	        		   else{
	        			   connectionSocket.close();
	        			   System.out.println("Disconected");
	        			   break;
	        		   }
	        			   }
	        	   
	           
	           
	           }
	           else
	        	    System.out.println("server says: "+Sentence);

	        		   }
	          } 
	      


}
	    
